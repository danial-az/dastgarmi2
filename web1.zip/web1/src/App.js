import DrawingApp from './DrawingApp';

function App() {
  return <DrawingApp />;
}

export default App;